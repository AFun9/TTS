#ifndef SHARED_H_
#define SHARED_H_

#ifdef _WIN32
#define PIPERPHONEMIZE_EXPORT __declspec(dllexport)
#else
#define PIPERPHONEMIZE_EXPORT
#endif


#endif // SHARED_H_
